public class Config {
    public static final float PI = 3.141592653589793f;
}
