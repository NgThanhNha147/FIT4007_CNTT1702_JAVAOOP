
public class Triangle implements InterfaceShape {
    private int a, b, c;
    @Override
    public double calculatePerimeter() {
        return a + b + c;
    }
    @Override
    public double calculateArea() {
        float semiPerimeter = (a + b + c ) / 2;
        return Math.sqrt(semiPerimeter * (semiPerimeter - a) * (semiPerimeter - b) * (semiPerimeter - c));
    }

}
