public interface InterfaceShape {
    public double calculateArea();
    public double calculatePerimeter();
}
