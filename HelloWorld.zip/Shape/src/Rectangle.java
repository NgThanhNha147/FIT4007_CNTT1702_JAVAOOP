
public class Rectangle implements InterfaceShape {
    private int width;
    private int height;
    @Override
    public double calculateArea() {
        return width * height;
    }

    @Override
    public double calculatePerimeter() {
        return (width + height) *2;
    }
}
