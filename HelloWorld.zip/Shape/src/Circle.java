public class Circle implements InterfaceShape {
    private double radius;
    @Override
    public double calculateArea() {
    return Config.PI * ( radius * radius);
    }

    @Override
    public double calculatePerimeter() {
    return 2 * radius * Config.PI;
    }
}
