import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class HangThucPham {
    private final String maHang;
    private String tenHang;
    private int donGia;
    private Date ngaySX;
    private Date ngayHH;
    DecimalFormat df = new DecimalFormat("#,### VND");
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

    public HangThucPham(String maHang, String tenHang, int donGia, Date ngaySX, Date ngayHH) {
        this.maHang = maHang;
        setTenHang(tenHang);
        this.donGia = donGia;
        this.ngaySX = ngaySX;
        this.ngayHH = ngayHH;
    }

    private void setTenHang(String tenHang) {
        if (tenHang == null || tenHang.isEmpty()){
            this.tenHang = "Mac_dinh";
        }else {
            this.tenHang = tenHang;
        }
    }

    private String getMaHang() {
        return maHang;
    }

    private String getTenHang() {
        return tenHang;
    }

    private void setTenHang() {

    }

    private int getDonGia() {
        return donGia;
    }

    private void setDonGia(int donGia) {
        this.donGia = donGia;
    }

    private Date getNgaySX() {
        return ngaySX;
    }

    private void setNgaySX(Date ngaySX) {
        this.ngaySX = ngaySX;
    }

    private Date getNgayHH() {
        return ngayHH;
    }

    private void setNgayHH(Date ngayHH) {
        this.ngayHH = ngayHH;
    }
    private boolean ngayHethan(){
        long millis=System.currentTimeMillis();
        java.sql.Date date=new java.sql.Date(millis);
        ngayHH.after(date);
        return false;
    }


    @Override
    public String toString() {
        return "HangThucPham:" +
                "\nmaHang: " + maHang +
                "\ntenHang: " + tenHang +
                "\ndonGia: " + df.format(donGia) +
                "\nngaySX: " + sdf.format(ngaySX) +
                "\nngayHH: " + sdf.format(ngayHH);
    }
}
