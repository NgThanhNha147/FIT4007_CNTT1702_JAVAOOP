import java.util.Scanner;

public class GreatestCommonDivisor {

}
