import java.util.regex.Pattern;

public class Student {
    private String stdcode;
    private String name;
    private String dateOfBirth;
    private String sex;
    private String specialized;
    private String idCard;           // Identification Card
    private String phone;
    private String email;
    private String address;

    // Constructor
    public Student() {
        this.stdcode = stdcode;
        this.name = name;
        this.dateOfBirth = dateOfBirth;
        this.sex = sex;
        this.specialized = specialized;
        this.idCard = idCard;
        this.phone = phone;
        this.email = email;
        this.address = address;
    }
    private boolean isValidEmail(String email) {
        String emailRegex = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";
        return Pattern.matches(emailRegex, email);
    }

    private boolean isValidPhoneNumber(String phoneNumber) {
        String phoneRegex = "^[0-9]{10}$";
        return Pattern.matches(phoneRegex, phoneNumber);
    }

    // Setter methods with validation
    public void setStdcode(String stdcode) {
        if (stdcode == null || stdcode.isEmpty()) {
            throw new IllegalArgumentException("Mã không hợp lệ");
        }
        this.stdcode = stdcode;
    }

    public void setName(String name) {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Tên không hợp lệ");
        }
        this.name = name;
    }
    public String getName() {
        return name;
    }



    public void setEmail(String email) {
        if (!isValidEmail(email)) {
            throw new IllegalArgumentException("Email không hợp lệ");
        }
        this.email = email;
    }

    public void setPhoneNumber(String phoneNumber) {
        if (!isValidPhoneNumber(phoneNumber)) {
            throw new IllegalArgumentException("Số điện thoại không hợp lệ");
        }
        this.phone = phoneNumber;
    }
    // Getters and Setters
    public String getStdcode() {
        return stdcode;
    }


    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getSpecialized() {
        return specialized;
    }

    public void setSpecialized(String specialized) {
        this.specialized = specialized;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }


    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "MSV: " + stdcode + "\nHọ Và Tên: " + name + "\nNgày Sinh: " + dateOfBirth +
                "\nGiới Tính: " + sex + "\nChuyên Ngành: " + specialized + "\nCCCD: " + idCard +
                "\nSDT: " + phone + "\nEmail: " + email + "\nĐịa Chỉ: " + address;
    }

}
