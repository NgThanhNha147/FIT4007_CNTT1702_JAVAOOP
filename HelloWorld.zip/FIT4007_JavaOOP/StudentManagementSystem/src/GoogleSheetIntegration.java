import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class GoogleSheetIntegration {

    public void sendToGoogleSheet(Student student) {
        try {
            String formURL = "https://docs.google.com/forms/u/0/d/e/1FAIpQLSdJUFvjnW4OJg2-P4P3I-SgXirxqGewq7tb9vSr-YRQwoSDRw/formResponse";

            String data = "entry.1051476100=" + student.getStdcode() +
                    "&entry.1747411951=" + student.getName() +
                    "&entry.303143956=" + student.getDateOfBirth() +
                    "&entry.1415510108=" + student.getSex() +
                    "&entry.1688719127=" + student.getSpecialized() +
                    "&entry.743326831=" + student.getIdCard() +
                    "&entry.69783829=" + student.getPhone() +
                    "&entry.1766469891=" + student.getEmail() +
                    "&entry.46881770=" + student.getAddress();

            URL url = new URL(formURL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = data.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                System.out.println("\nThem sinh vien thanh cong");
            } else {
                System.out.println("\nThem sinh vien khong thanh cong");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
