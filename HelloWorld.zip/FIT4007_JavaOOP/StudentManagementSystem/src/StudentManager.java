import java.util.ArrayList;
import java.util.Scanner;

public class StudentManager {
    private ArrayList<Student> student;

    public StudentManager() {
        student = new ArrayList<>();
    }
    public void addStudent() {
        Scanner sc = new Scanner(System.in);
        Student newStudent = new Student();
        GoogleSheetIntegration googleSheet = new GoogleSheetIntegration();

        System.out.println("Vui lòng nhập thông tin sinh viên mới");
        while (true) {
            System.out.print("MSV: ");
            String stdcode = sc.nextLine();
            try {
                newStudent.setStdcode(stdcode);
                break;
            } catch (IllegalArgumentException e) {
                System.out.println("Lỗi: " + e.getMessage() + ". Vui lòng nhập lại.");
            }
        }

        // Nhập họ và tên
        while (true) {
            System.out.print("Họ Và Tên: ");
            String name = sc.nextLine();
            try {
                newStudent.setName(name);
                break;
            } catch (IllegalArgumentException e) {
                System.out.println("Lỗi: " + e.getMessage() + ". Vui lòng nhập lại.");
            }
        }

        // Nhập ngày sinh
        while (true) {
            System.out.print("Ngày Sinh (yyyy-mm-dd): ");
            String dateOfBirth = sc.nextLine();
            try {
                newStudent.setDateOfBirth(dateOfBirth);
                break;
            } catch (IllegalArgumentException e) {
                System.out.println("Lỗi: " + e.getMessage() + ". Vui lòng nhập lại.");
            }
        }

        while (true) {
            System.out.print("Giới Tính: ");
            String sex = sc.nextLine();
            try {
                newStudent.setSex(sex);
                break;
            } catch (IllegalArgumentException e) {
                System.out.println("Lỗi: " + e.getMessage() + ". Vui lòng nhập lại.");
            }
        }
        while (true) {
            System.out.print("Chuyên Ngành: ");
            String specialized = sc.nextLine();
            try {
                newStudent.setSpecialized(specialized);
                break;
            } catch (IllegalArgumentException e) {
                System.out.println("Lỗi: " + e.getMessage() + ". Vui lòng nhập lại.");
            }
        }
        while (true) {
            System.out.print("CCCD: ");
            String idCard = sc.nextLine();
            try {
                newStudent.setIdCard(idCard);
                break;
            } catch (IllegalArgumentException e) {
                System.out.println("Lỗi: " + e.getMessage() + ". Vui lòng nhập lại.");
            }
        }
        while (true) {
            System.out.print("SDT: ");
            String phone = sc.nextLine();
            try {
                newStudent.setPhoneNumber(phone);
                break;
            } catch (IllegalArgumentException e) {
                System.out.println("Lỗi: " + e.getMessage() + ". Vui lòng nhập lại.");
            }
        }
        while (true) {
            System.out.print("Email: ");
            String email = sc.nextLine();
            try {
                newStudent.setEmail(email);
                break;
            } catch (IllegalArgumentException e) {
                System.out.println("Lỗi: " + e.getMessage() + ". Vui lòng nhập lại.");
            }
        }
        while (true) {
            System.out.print("Địa Chỉ: ");
            String address = sc.nextLine();
            try {
                newStudent.setAddress(address);
                break;
            } catch (IllegalArgumentException e) {
                System.out.println("Lỗi: " + e.getMessage() + ". Vui lòng nhập lại.");
            }
        }

        student.add(newStudent);
        googleSheet.sendToGoogleSheet(newStudent);
//        System.out.println("Thêm sinh viên thành công.");
    }
    public void editStudent() {
        Scanner sc = new Scanner(System.in);

        System.out.print("Nhập MSV của sinh viên cần sửa: ");
        String stdcode = sc.nextLine();

        // Tìm sinh viên có MSV tương ứng
        Student studentToEdit = null;
        for (Student std : student) {
            if (std.getStdcode() != null && std.getStdcode().equals(stdcode)) {
                studentToEdit = std;
                break;
            }
        }

        // Nếu sinh viên không tồn tại
        if (studentToEdit == null) {
            System.out.println("Không tìm thấy sinh viên với MSV: " + stdcode);
            return;
        }

        // Bắt đầu sửa thông tin sinh viên
        System.out.println("Bắt đầu chỉnh sửa thông tin sinh viên. Để trống nếu không muốn thay đổi.");

        // Sửa tên
        System.out.print("Họ và tên (" + studentToEdit.getName() + "): ");
        String newName = sc.nextLine();
        if (!newName.isEmpty()) {
            studentToEdit.setName(newName);
        }

        // Sửa ngày sinh
        System.out.print("Ngày sinh (" + studentToEdit.getDateOfBirth() + "): ");
        String newDateOfBirth = sc.nextLine();
        if (!newDateOfBirth.isEmpty()) {
            studentToEdit.setDateOfBirth(newDateOfBirth);
        }

        // Sửa giới tính
        System.out.print("Giới tính (" + studentToEdit.getSex() + "): ");
        String newSex = sc.nextLine();
        if (!newSex.isEmpty()) {
            studentToEdit.setSex(newSex);
        }

        // Sửa chuyên ngành
        System.out.print("Chuyên ngành (" + studentToEdit.getSpecialized() + "): ");
        String newSpecialized = sc.nextLine();
        if (!newSpecialized.isEmpty()) {
            studentToEdit.setSpecialized(newSpecialized);
        }

        // Sửa CCCD
        System.out.print("CCCD (" + studentToEdit.getIdCard() + "): ");
        String newIdCard = sc.nextLine();
        if (!newIdCard.isEmpty()) {
            studentToEdit.setIdCard(newIdCard);
        }

        // Sửa số điện thoại
        System.out.print("Số điện thoại (" + studentToEdit.getPhone() + "): ");
        String newPhone = sc.nextLine();
        if (!newPhone.isEmpty()) {
            studentToEdit.setPhone(newPhone);
        }

        // Sửa email
        System.out.print("Email (" + studentToEdit.getEmail() + "): ");
        String newEmail = sc.nextLine();
        if (!newEmail.isEmpty()) {
            studentToEdit.setEmail(newEmail);
        }

        // Sửa địa chỉ
        System.out.print("Địa chỉ (" + studentToEdit.getAddress() + "): ");
        String newAddress = sc.nextLine();
        if (!newAddress.isEmpty()) {
            studentToEdit.setAddress(newAddress);
        }

        // In thông tin sinh viên sau khi đã sửa
        System.out.println("Thông tin sinh viên sau khi sửa:");
        System.out.println(studentToEdit.toString());
    }
    public void displayStudents() {
        if (student.isEmpty()) {
            System.out.println("Danh sách sinh viên trống.");
        } else {
            System.out.println("===== Danh Sách Sinh Viên =====");
            for (Student std : student) {
                System.out.println(std.toString());  // Gọi toString() của mỗi sinh viên
                System.out.println("------------------------------");
            }
        }
    }
}
