public class SubjectsManager {
}
