public class Class {
    private String classID;
    private String className;
    private String academicYear;
    private String teacherID;

    public Class(String classID, String className, String academicYear, String teacherID) {
        setClassID(classID);
        setClassName(className);
        setAcademicYear(academicYear);
        setTeacherID(teacherID);
    }
    public void setClassID(String classID) {
        if (classID == null || classID.isEmpty()) {
            throw new IllegalArgumentException("Mã không hợp lệ");
        }
        this.classID = classID;
    }
    public void setClassName(String className) {
        this.className = className;
    }

    public void setAcademicYear(String academicYear) {
        this.academicYear = academicYear;
    }

    public void setTeacherID(String teacherID) {
        this.teacherID = teacherID;
    }

    public String getClassID() {
        return classID;
    }

    public String getClassName() {
        return className;
    }

    public String getAcademicYear() {
        return academicYear;
    }

    public String getTeacherID() {
        return teacherID;
    }


}