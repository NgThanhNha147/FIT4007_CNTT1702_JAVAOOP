import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StudentManager studentManager = new StudentManager();
        int choice;

        do {
            System.out.println("\n===== Quản lý chức năng =====");
            System.out.println("Xin chào, tôi có thể giúp gì cho bạn?");
            System.out.println("1. Quản lý Sinh viên");
            System.out.println("2. Quản lý Lớp học");
            System.out.println("3. Quản lý Môn học");
            System.out.println("4. Quản lý Điểm số");
            System.out.println("5. Quản lý Giáo viên");
            System.out.println("6. Quản lý Ngành");
            System.out.println("7. Quản lý Khoa");
            System.out.println("8. Quản lý Khoá học");
            System.out.println("0. Thoát");
            System.out.print("Chọn chức năng bạn cần: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    manageStudents(scanner, studentManager);
                    break;
                case 2:
                    manageClasses(scanner);
                    break;
                case 3:
                    manageSubjects(scanner);
                    break;
                case 4:
                    manageGrades(scanner);
                    break;
                case 5:
                    manageTeachers(scanner);
                    break;
                case 6:
                    manageMajors(scanner);
                    break;
                case 7:
                    manageDepartments(scanner);
                    break;
                case 8:
                     manageCourse(scanner);
                    break;
                case 0:
                    System.out.println("Thoát chương trình.");
                    break;
                default:
                    System.out.println("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
            }
        } while (choice != 0);

        scanner.close();
    }

    private static void manageStudents(Scanner scanner, StudentManager studentManager) {
        System.out.println("\n===== Quản lý Sinh viên =====");
        System.out.println("1. Thêm sinh viên mới");
        System.out.println("2. Sửa thông tin sinh viên");
        System.out.println("3. Xóa sinh viên");
        System.out.println("4. Tìm kiếm sinh viên");
        System.out.println("5. Hiển Thị Danh Sách Sinh Viên");
        System.out.println("6. Quay Lại");
        System.out.print("Chọn chức năng bạn cần: ");
        // Gọi các hàm tương ứng
        int option = scanner.nextInt();
        switch (option) {
            case 1:
                studentManager.addStudent();
                break;
            case 2:
                studentManager.editStudent();
                break;
            case 3:
                // xóa sinh viên
                break;
            case 4:
                // tìm kiếm sinh viên
                break;
            case 5:
                studentManager.displayStudents();
                break;
            case 6:
                System.out.println("Quay lại menu chính...");
                return;
            default:
                System.out.println("Lựa chọn không hợp lệ.");
        }
    }

    private static void manageClasses(Scanner scanner) {
        System.out.println("\n===== Quản lý Lớp học =====");
        System.out.println("1. Thêm lớp mới");
        System.out.println("2. Sửa thông tin lớp học");
        System.out.println("3. Xóa lớp học");
        System.out.println("4. Tìm kiếm lớp");
        System.out.println("5. Xem danh sách sinh viên trong lớp");
        System.out.println("6. Quay Lại");
        System.out.print("Chọn chức năng bạn cần: ");
        // Gọi các hàm tương ứng
        int option = scanner.nextInt();
        switch (option) {
            case 1:
                // thêm lớp học
                break;
            case 2:
                // sửa thông tin lớp học
                break;
            case 3:
                // xóa lớp học
                break;
            case 4:
                // tìm kiếm lớp
                break;
            case 5:
                // xem danh sách sinh viên trong lớp
                break;
            case 6:
                System.out.println("Quay lại menu chính...");
                return;
            default:
                System.out.println("Lựa chọn không hợp lệ.");
        }
    }
    private static void manageSubjects(Scanner scanner) {
        System.out.println("\n===== Quản lý Môn học =====");
        System.out.println("1. Thêm môn học mới");
        System.out.println("2. Sửa thông tin môn học");
        System.out.println("3. Tìm kiếm môn học");
        System.out.println("4. Xem danh sách lớp học môn đó");
        System.out.println("5. Quay Lại");
        System.out.print("Chọn chức năng bạn cần: ");
        // Gọi các hàm tương ứng
        int option = scanner.nextInt();
        switch (option) {
            case 1:
                // thêm môn học
                break;
            case 2:
                // sửa thông tin môn học
                break;
            case 3:
                // tìm kiếm môn học
                break;
            case 4:
                // xem danh sách lớp học môn đó
                break;
            case 5:
                System.out.println("Quay lại menu chính...");
                return;
            default:
                System.out.println("Lựa chọn không hợp lệ.");
        }
    }

    private static void manageGrades(Scanner scanner) {
        System.out.println("\n===== Quản lý Điểm số =====");
        System.out.println("1. Nhập điểm giữa kỳ");
        System.out.println("2. Nhập điểm cuối kỳ");
        System.out.println("3. Tính điểm trung bình môn học");
        System.out.println("4. Xem bảng điểm của sinh viên");
        System.out.println("5. Quay Lại");
        System.out.print("Chọn chức năng bạn cần: ");
        // Gọi các hàm tương ứng
        int option = scanner.nextInt();
        switch (option) {
            case 1:
                // nhập điểm giữa kỳ
                break;
            case 2:
                // nhập điểm cuối kỳ
                break;
            case 3:
                // tính điểm trung bình
                break;
            case 4:
                // xem bảng điểm
                break;
            case 5:
                System.out.println("Quay lại menu chính...");
                return;
            default:
                System.out.println("Lựa chọn không hợp lệ.");
        }
    }
    private static void manageTeachers(Scanner scanner) {
        System.out.println("\n===== Quản lý Giáo Viên =====");
        System.out.println("1. Thêm giáo viên mới");
        System.out.println("2. Sửa thông tin");
        System.out.println("3. Danh sách giáo viên (theo ngành, khoa)");
        System.out.println("4. Xoá giáo viên khỏi hệ thống");
        System.out.println("5. Quay Lại");
        System.out.print("Chọn chức năng bạn cần: ");
        // Gọi các hàm tương ứng
        int option = scanner.nextInt();
        switch (option) {
            case 1:

                break;
            case 2:

                break;
            case 3:

                break;
            case 4:

                break;
            case 5:
                System.out.println("Quay lại menu chính...");
                return;
            default:
                System.out.println("Lựa chọn không hợp lệ.");
        }
    }
    private static void manageMajors(Scanner scanner) {
        System.out.println("\n===== Quản lý Ngành =====");
        System.out.println("1. Thêm ngành mới");
        System.out.println("2. Sửa thông tin");
        System.out.println("3. Danh sách ngành");
        System.out.println("4. Tìm kiếm ngành");
        System.out.println("4. Xoá ngành khỏi hệ thống");
        System.out.println("5. Quay Lại");
        System.out.print("Chọn chức năng bạn cần: ");
        // Gọi các hàm tương ứng
        int option = scanner.nextInt();
        switch (option) {
            case 1:

                break;
            case 2:

                break;
            case 3:

                break;
            case 4:

                break;
            case 5:
                System.out.println("Quay lại menu chính...");
                return;
            default:
                System.out.println("Lựa chọn không hợp lệ.");
        }
    }
    private static void manageDepartments(Scanner scanner) {
        System.out.println("\n===== Quản lý Khoa =====");
        System.out.println("1. Thêm khoa mới");
        System.out.println("2. Sửa thông tin");
        System.out.println("3. Danh sách khoa");
        System.out.println("4. Tìm kiếm khoa");
        System.out.println("4. Xoá khoa khỏi hệ thống");
        System.out.println("5. Quay lại");
        System.out.print("Chọn chức năng bạn cần: ");
        // Gọi các hàm tương ứng
        int option = scanner.nextInt();
        switch (option) {
            case 1:

                break;
            case 2:

                break;
            case 3:

                break;
            case 4:

                break;
            case 5:
                System.out.println("Quay lại menu chính...");
                return;
            default:
                System.out.println("Lựa chọn không hợp lệ.");
        }
    }
    private static void manageCourse(Scanner scanner) {
        System.out.println("\n===== Quản lý Khoá học =====");
        System.out.println("1. Thêm khoá học mới");
        System.out.println("2. Sửa thông tin");
        System.out.println("3. Danh sách các khoá học");
        System.out.println("4. Tìm kiếm khoá học");
        System.out.println("4. Xoá khoá học khỏi hệ thống");
        System.out.println("5. Quay Lại");
        System.out.print("Chọn chức năng bạn cần: ");
        // Gọi các hàm tương ứng
        int option = scanner.nextInt();
        switch (option) {
            case 1:

                break;
            case 2:

                break;
            case 3:

                break;
            case 4:

                break;
            case 5:
                System.out.println("Quay lại menu chính...");
                return;
            default:
                System.out.println("Lựa chọn không hợp lệ.");
        }
    }
}