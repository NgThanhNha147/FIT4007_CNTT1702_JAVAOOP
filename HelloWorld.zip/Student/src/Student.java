public class Student {
//    properties
    public int id;
    public String fullname;
    public float point1,point2;

    //    Constructor
    public Student(){
        this.id = 0;
        this.fullname = "";
        this.point1 = 0;
        this.point2 = 0;
    }

    public Student(int id, String fullname, float point1, float
            point2) {
        this.id = id;
        this.fullname = fullname;
        this.point1 = point1;
        this.point2 = point2;
    }

//    Setter-getter
//    public int getId() {
//        return id;
//    }
//    public String getFullname() {
//        return this.fullname;
//    }
//    public float getPoint1() {
//        return this.point1;
//    }
//    public float getPoint2() {
//        return this.point2;
//    }
//    public void setFullname(String fullname) {
//        this.fullname = fullname;
//    }

    public double getAverage(){
        return (this.point1+this.point2)/2;
    }

//    other methods

}
