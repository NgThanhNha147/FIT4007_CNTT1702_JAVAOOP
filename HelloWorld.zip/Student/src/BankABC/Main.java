package BankABC;

import java.text.DecimalFormat;
import java.util.Scanner;
import BankABC.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
//        System.out.print("Nhap So Tai Khoan: ");
//        long accountNumber = sc.nextLong();
//        System.out.print("Nhap Ten Tai Khoan: ");
//        sc.nextLine();
//        String accountName = sc.nextLine();
        DecimalFormat df = new DecimalFormat("#,### VND");
//        goi class Account truyen tham so
//        Account account = new Account(accountNumber, accountName);
//        System.out.println("Thong Tin Bank: ");
//        System.out.println("STK: "+account.accountNumber+"\nCTK: "+account.accountName+"\nSoDu: "+df.format(account.getBalance()));
        Account account1 = new Account(123, "Nha Dan", 100000);
        System.out.println("Thong Tin Bank 2: ");
        System.out.println("STK: "+account1.accountNumber+"\nCTK: "+account1.accountName+"\nSoDu: "+df.format(account1.getBalance()));

        System.out.print("Nhap So Tien Muon Nap: ");
        double amount = sc.nextDouble();
        account1.deposit(amount);
        System.out.println("So Tien Sau Khi Nap: "+df.format(account1.balance));
        System.out.println("Nhap So Tien Rut ( Phi: 100d ): ");
        double amount2 = sc.nextDouble();
        account1.withdraw(amount2,100);
        System.out.println("So Du: "+df.format(account1.balance));
    }
}
