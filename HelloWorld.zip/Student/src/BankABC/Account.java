package BankABC;

public class Account {
    public long accountNumber;
    public String accountName;
    public double balance;
    public static final double rate = 0.035;
    public Account() {
        accountNumber = 0;
        accountName = "";
        balance = 0;
    }
    public Account(long accountNumber, String accountName) {
        this.accountNumber = accountNumber;
        this.accountName = accountName;
        this.balance = 50;
    }
    public Account(long accountNumber, String accountName, double balance) {
        this.accountNumber = accountNumber;
        this.accountName = accountName;
        this.balance = balance;
    }

    public String getAccountName() {
        return accountName;
    }

    public long getAccountNumber() {
        return accountNumber;
    }

    public double getBalance() {
        return balance;
    }

    public void setAccountNumber(long accountNumber) {
        this.accountNumber = accountNumber;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
//    Nap Tien
    public void deposit(double amount) {
        if (amount <= 0) {
            System.out.println("So tien nap phai lon hon 0.");
        }else {
            this.balance += amount;
        }
    }
//    Rut Tien
    public void withdraw(double amount, double fee) {
        if (amount + fee > 0 && (amount + fee) <= this.balance) {
            this.balance -= (amount + fee);
        } else {
            System.out.println("tài khoản hết tiền hoặc số tiền rút không hợp lệ!");
        }
    }
}
