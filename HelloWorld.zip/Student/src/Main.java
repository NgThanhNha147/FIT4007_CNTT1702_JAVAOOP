import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap thong tin sinh vien 3: ");
        System.out.print("Ma Sinh Vien: ");
        int id = sc.nextInt();
        System.out.print("Full Name: ");
        sc.nextLine();
        String fullName = sc.nextLine();
        System.out.print("Diem Ly Thuyet: ");
        float point1 = sc.nextInt();
        System.out.print("Diem Thuc Hanh: ");
        float point2 = sc.nextInt();
//        sinh vien 1
        Student student1 = new Student(101, "Nha Ngu", 9f, 8f);
        System.out.println("----------------\nThong tin sinh vien 1");
        System.out.println("Ma Sinh Vien: "+student1.id+"\nFull Name: "+student1.fullname+"\nDiem Ly Thuyet: "+student1.point1+"\nDiem Thuc Hanh: "+student1.point2+"\nDiem Trung Binh: "+ student1.getAverage());


//        sinh vien 2
        Student student2 = new Student(102, "Son Oc Cho", 2f, 1f);
        System.out.println("----------------\nThong tin sinh vien 2");
        System.out.println("Ma Sinh Vien: "+student2.id+"\nFull Name: "+student2.fullname+"\nDiem Ly Thuyet: "+student2.point1+"\nDiem Thuc Hanh: "+student2.point2+"\nDiem Trung Binh: "+ student2.getAverage());


//        sinh vien 3
        Student student = new Student(id, fullName, point1, point2);
        System.out.println("----------------\nThong tin sinh vien 3");
        System.out.println("Ma Sinh Vien: "+id+"\nFull Name: "+fullName+"\nDiem Ly Thuyet: "+point1+"\nDiem Thuc Hanh: "+point2+"\nDiem Trung Binh: "+ student.getAverage());
    }
}