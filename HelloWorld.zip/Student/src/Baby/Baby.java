package Baby;

public class Baby {
    static String classIt = "17-02";
    static int numBabiesMade = 0;

}
