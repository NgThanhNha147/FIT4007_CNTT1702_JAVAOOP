package Baby;

import static Baby.Baby.classIt;
import static Baby.Baby.numBabiesMade;

public class Main {
    public static void main(String[] args) {
        System.out.print("Cntt "+ classIt);
    }
}
