import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Chieu Dai: ");
        double height = sc.nextInt();
        System.out.print("Chieu Rong: ");
        double width = sc.nextInt();

        Rectangle rectangle = new Rectangle(width, height);
        System.out.println(rectangle.toString());
    }
}