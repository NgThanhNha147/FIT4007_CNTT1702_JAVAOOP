import java.util.Scanner;

public class Common {
    // Hàm tính ƯCLN bằng thuật toán Euclid
//    public static int GCD (int a, int b) {
//        while (b != 0) {
//            int temp = b;
//            b = a % b;
//            a = temp;
//        }
//        return a;
//    }
//
//    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//
//        // Nhập hai số nguyên từ người dùng
//        System.out.print("Nhập số thứ nhất: ");
//        int a = scanner.nextInt();
//        System.out.print("Nhập số thứ hai: ");
//        int b = scanner.nextInt();
//
//        // Tính và in ra ƯCLN của hai số
//        int result = GCD(a, b);
//        System.out.println("Ước chung lớn nhất của " + a + " và " + b + " là: " + result);
//    }
    public static void main(String[] args) {
        int a,b;
        int GreatestCommonDivisor = 0;
        Scanner sc = new Scanner(System.in);
        // input
        System.out.println("Nhap 2 so nguyen: ");
        a = sc.nextInt();
        b = sc.nextInt();
        while ( a != b){
            if (a > b){
                b = b - a;
            }
            else {
                a = a - b;
            }
        }
        GreatestCommonDivisor = b;
        System.out.println("Ước chung lớn nhất là: " + GreatestCommonDivisor );


    }
}
