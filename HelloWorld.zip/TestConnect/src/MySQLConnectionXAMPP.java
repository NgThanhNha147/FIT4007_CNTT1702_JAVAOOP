import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MySQLConnectionXAMPP {
    // Thông tin kết nối MySQL
    private static final String URL = "jdbc:mysql://localhost:3306/test_db";  // tên database của bạn
    private static final String USER = "root";  // Tài khoản mặc định là 'root'
    private static final String PASSWORD = "";  // Mặc định trong XAMPP mật khẩu để trống

    public static void main(String[] args) {
        Connection connection = null;

        try {
            // Tải MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Kết nối tới database
            connection = DriverManager.getConnection(URL, USER, PASSWORD);

            if (connection != null) {
                System.out.println("Kết nối thành công với MySQL từ XAMPP!");
            } else {
                System.out.println("Kết nối thất bại!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            // Đóng kết nối
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
