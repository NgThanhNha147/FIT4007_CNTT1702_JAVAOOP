import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Scanner sc = new Scanner(System.in);
        System.out.println("Ngay SX: ");
        String daySX = sc.nextLine();
        Date importedDateSX = sdf.parse(daySX);
        System.out.println("Ngay HH: ");
        String dayHH = sc.nextLine();
        Date importedDateHH = sdf.parse(dayHH);

        HangThucPham thucPham1 = new HangThucPham(null, "Cam", 10000, importedDateSX, importedDateHH);
        if (thucPham1.maHang != null && thucPham1.tenHang != null && thucPham1.donGia > 0 && thucPham1.ngaySX != null) {
            System.out.println(thucPham1.toString());
        }else{
            System.out.println("Không Hợp lệ, mã hàng !=null, tên hàng != null,đơn giá > 0, ngaySX != null");
        }




    }
}