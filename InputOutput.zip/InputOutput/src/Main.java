import java.io.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
//        File file = new File("src/data/input2.txt");
        File file = new File("src/data/input2.txt");
        try{

//            FileReader fr = new FileReader(file);
//            BufferedReader br = new BufferedReader(fr);
//            String line;
//            while ((line = br.readLine()) != null){
//                System.out.println(line);
//            }



//            Ghi Du Lieu
//            FileWriter fw = new FileWriter(file);
//            BufferedWriter bw = new BufferedWriter(fw);
//            Scanner sc = new Scanner(System.in);
//            System.out.print("Id: ");
//            int id = sc.nextInt();
//            bw.write(id + "\t");
//            System.out.print("Name: ");
//            sc.nextLine();
//            String name = sc.nextLine();
//            bw.write(name+"\t");
//            System.out.print("Address: ");
//            String address = sc.nextLine();
//            bw.write(address+"\t");
//            bw.close();


//            Ghi Du Lieu Nang Cao
            FileOutputStream fos = new FileOutputStream(file);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            Scanner sc = new Scanner(System.in);
            System.out.print("Id: ");
            int id = sc.nextInt();
            System.out.print("Name: ");
            sc.nextLine();
            String name = sc.nextLine();
            System.out.print("Address: ");
            String address = sc.nextLine();
//            Ghi DOi TUong Vao File
            Students std = new Students(id, name, address);
            oos.writeObject(std);
            oos.close();
//            Đọc Tep Tin
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            Students student = (Students) ois.readObject();
            System.out.println("Doc Doi Tuong Tu Tep Tin");
            System.out.println(student);
        }catch (IOException | ClassNotFoundException e){
            System.out.println(e.getMessage());
        }

    }
}